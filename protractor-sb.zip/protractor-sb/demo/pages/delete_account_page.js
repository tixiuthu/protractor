

var expect = require('./../../expect.js');
var DeleteAccountPage = function() {

    this.getURL = function(value) {
        browser.get(value);
        browser.sleep(5000);
    };

    this.clickCustomers = function(){
        element(by.buttonText('Customers')).click();
    }

    this.verifyCustomersScreen = function(){
        expect(element(by.repeater('cust in Customers | orderBy:sortType:sortReverse | filter:searchCustomer'))).to.be.present;
    }


    this.verifyOpenAccount = function(customer){
        this.clickCustomers();
    };

    this.verifyDeletedCustomer = function(){
        var customers = element.all(by.repeater('cust in Customers | orderBy:sortType:sortReverse | filter:searchCustomer'));
        var lastCustRow = customers.last();

        element.all(by.repeater('cust in Customers | orderBy:sortType:sortReverse | filter:searchCustomer')).then(function(rows) {
            browser.executeScript("return arguments[0].offsetTop;", lastCustRow.getWebElement()).then(function (offset) {
                browser.executeScript('arguments[0].scrollTop = arguments[1];', lastCustRow, offset).then(function () {

                });
            });
        });
    }

    this.deleteAccount = function(input_fname,input_lname,input_postCd){
        var customers = element.all(by.repeater('cust in Customers | orderBy:sortType:sortReverse | filter:searchCustomer'));
        var lastCustRow = customers.last();

        element.all(by.repeater('cust in Customers | orderBy:sortType:sortReverse | filter:searchCustomer')).then(function(rows) {
            browser.executeScript("return arguments[0].offsetTop;", lastCustRow.getWebElement()).then(function (offset) {
                browser.executeScript('arguments[0].scrollTop = arguments[1];', lastCustRow, offset).then(function() {

                });
            });
            rows.forEach(function(row){
                var checkInfo = false;
                row.all(by.tagName('td')).then(function (columns) {

                    columns[0].getAttribute('innerText').then(function(fname){
                        if(fname === input_fname){
                            checkInfo = true;

                        }else{
                            checkInfo = false;
                        }

                    });
                    columns[1].getAttribute('innerText').then(function(lname){
                        if(checkInfo){
                            if(lname === input_lname){
                                checkInfo = true;

                            }else{
                                checkInfo = false;
                            }
                        }

                    });
                    columns[2].getAttribute('innerText').then(function(code){
                        if(checkInfo){
                            if(code === input_postCd){
                                checkInfo = true;

                            }else{
                                checkInfo = false;
                            }
                            if(checkInfo == true){
                                columns[4].all(by.tagName('button')).get(0).click();
                                browser.sleep(4000);
                            }
                        }

                    });


                });

            });
        });

    }

};
module.exports = DeleteAccountPage;