/**
 * Created by nguyenthihongthuy on 30/08/17.
 */
var expect = require('./../../expect.js');
var OpenAccountPage = function() {

    this.getURL = function(value) {
        browser.get(value);
        browser.sleep(5000);
    };

    this.setCustomerName = function(value) {
        element(by.cssContainingText('option', value)).click();
        browser.sleep(1000);
    };

    this.setCurrency = function(value) {
        element(by.cssContainingText('option', value)).click();
        browser.sleep(1000);
    };

    this.clickOpenAccount = function() {
        element(by.buttonText('Open Account')).click();
        browser.sleep(1000);
    }


    this.clickProcessBtn = function() {
        element(by.buttonText('Process')).click().then(function () {
            browser.switchTo().alert().accept();
        });
    }

    this.verifyCustomerExisted = function(value){
        expect(element(by.cssContainingText('option', value))).to.be.present;
    };

    this.verifyOpenAccountScreen = function(){
        expect(element(by.id('userSelect'))).to.be.present;
    }

};

module.exports = OpenAccountPage;
