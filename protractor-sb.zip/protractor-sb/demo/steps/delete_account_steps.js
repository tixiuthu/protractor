

var DeleteAccountSteps = function () {

    var CustomersListPage = require("../pages/delete_account_page.js");

    this.Before(function (scenario, callback) {
        this.customers_list_page = new CustomersListPage();
        callback();
    });


    this.When('I click on Customers button', function (callback) {
        this.customers_list_page. clickCustomers();
        callback();
    });

    this.Then('I verify the Delete Customers screen', function (callback) {
        this.customers_list_page.verifyCustomersScreen();
        callback();
    });

    this.Then('I delete first name as $fname , last name as $lname , postcode as $postcode', function (fname, lname, postcode, callback) {
        this.customers_list_page.deleteAccount(fname,lname,postcode);
        callback();
    });


    this.Then('I verify system is deleted customer successfully', function (callback) {

        this.customers_list_page.verifyDeletedCustomer();
        callback();
    });

    this.Then('I verify open account successfully with customer $customer', function (customer,callback) {
        this.open_account_page.clickOpenAccount();
        this.customers_list_page.verifyOpenAccount(customer);
        callback();
    });

}
module.exports = DeleteAccountSteps;