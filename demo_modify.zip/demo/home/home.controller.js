﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['UserService', '$rootScope'];
    function HomeController(UserService, $rootScope) {
        $('#side-menu').metisMenu();

        var vm = this;

        vm.user = null;

        initController();

        function initController() {
            loadCurrentUser();
            renderChart();
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                });
        }

        function renderChart() {
            var sampleData = [5, 2, 3, 3, 5, 3, 5, 2, 1];
            $(".quickstat-spark").sparkline(sampleData, {
                type: 'line',
                width: '100%',
                height: '50',
                minSpotColor: '',
                maxSpotColor: '',
                chartRangeMin: 1,
                chartRangeMax: 5,
                borderWidth: 7,
                borderColor: '#f5f5f5',
                lineColor: "rgba(26,179,148,0.8)",
                fillColor: "rgba(163,225,212,0.3)",
                spotColor: "#ed5565",
                nullColor: "#1ab394",
                lineWidth: 1.25,
                valueSpots: {'0:': '#ed5565', ':-0.1': '#428BCA', 'null': '#1ab394'},
            });

            var options = {
                series: {
                    font: {
                        lineHeight: 13,
                        style: "normal",
                        color: "rgba(255,255,255,0.8)"
                    },
                    points: {
                        radius: 3,
                        fill: true,
                        show: true
                    },
                    shadowSize: 1
                },
                xaxis: {
                    mode: "time",
                    timezone: 'browser',
                    max: null,
                    tickSize: [1, "day"],
                    font: {
                        lineHeight: 13,
                        style: "normal",
                        color: "#000000"
                    },
                    tickLength: 0,
                    axisLabel: null,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 1
                },
                yaxes: [
                    {
                        min: 0,
                        tickDecimals: 0,
                        position: "left",
                        axisLabel: 'Count',
                        font: {
                            lineHeight: 13,
                            style: "normal",
                            color: "#000000"
                        },
                        axisLabelUseCanvas: true,
                        axisLabelFontSizePixels: 12,
                        axisLabelColour: "#000000",
                        axisLabelFontFamily: 'Verdana, Arial',
                        axisLabelPadding: 3
                    }
                ],
                legend: {
                    noColumns: 0,
                    labelBoxBorderColor: "#000000",
                    position: "nw",
                    show: true
                },
                grid: {
                    borderWidth: 1,
                    borderColor: '#D9D9D9',
                    labelMargin: 10,
                    hoverable: true,
                    clickable: true,
                    mouseActiveRadius: 6
                }
            }
            var data = [];
            for (var i = 0; i < sampleData.length; i++) {
                var time1 = (new Date());
                var time = time1.setDate(time1.getDate() + i);
                data.push([time, sampleData[i]]);
            }
            var chartData1 = [{
                label: "user", data: data, lines: {
                    show: true,
                    lineWidth: 1.2,
                    fill: 0.5
                }, color: "#2BBDA8",
            }];
            $.plot($("#total-data-summary-chart-1"), chartData1, options, []);
            
            var chartData2 = [{
                label: "session", data: data, lines: {
                    show: true,
                    lineWidth: 1.2,
                    fill: 0.5
                }, color: "#F0AD4E"
            }];
            $.plot($("#total-data-summary-chart-2"), chartData2, options, []);
        }
    }

})();