(function () {
    'use strict';

    angular
        .module('app')
        .controller('ManageAppController', ManageAppController);

    ManageAppController.$inject = ['AppService', '$rootScope'];
    function ManageAppController(AppService, $rootScope) {
        $('#side-menu').metisMenu();
        var vm = this;

        vm.app = null;
        vm.appDelete = null;
        vm.isAdd = false;
        vm.isEdit = false;
        vm.allApps = [];
        vm.deleteApp = deleteApp;
        vm.addApp = addApp;
        vm.createApp = createApp;
        vm.editApp = editApp;
        vm.updateApp = updateApp;
        vm.cancelAddEdit = cancelAddEdit;
        vm.showModalDelete = showModalDelete;

        loadAllApps();
        
        function loadAllApps() {
            AppService.GetAll()
                .then(function (apps) {
                    vm.allApps = apps;
                });
        }

        function showModalDelete(deleteId) {
            vm.appDelete = {
                id: deleteId
            }
            $("#myModalDelete").modal("show");
        }

        function deleteApp() {
            AppService.Delete(vm.appDelete.id)
            .then(function () {
                vm.isEdit = false;
                vm.isAdd = false;
                vm.appDelete = null;
                $("#myModalDelete").modal("hide");
                loadAllApps();
            });
        }

        function addApp() {
            vm.isEdit = false;
            vm.isAdd = true;
            vm.app = {
                userBase: "Both"
            };
        }

        function cancelAddEdit() {
            vm.isAdd = false;
            vm.isEdit = false;
        }

        function createApp() {
            vm.dataLoading = true;
            AppService.Create(vm.app)
                .then(function (response) {
                    if (response.success) {
                        loadAllApps();
                    } else {
                        alert(response.message);
                    }
                    vm.dataLoading = false;
                    vm.isAdd = false;
                });
        }

        function editApp(id) {
            AppService.GetById(id)
                .then(function (app) {
                    vm.app = app;
                    vm.isEdit = true;
                    vm.isAdd = false;
                });
        }

        function updateApp() {
            vm.dataLoading = true;
            AppService.Update(vm.app)
                .then(function () {
                    loadAllApps();
                    vm.dataLoading = false;
                    vm.isEdit = false;
                });
        }
    }

})();