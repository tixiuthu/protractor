(function () {
    'use strict';

    angular
        .module('app')
        .controller('ManageController', ManageController);

    ManageController.$inject = ['UserService', '$rootScope'];
    function ManageController(UserService, $rootScope) {
        $('#side-menu').metisMenu();
        var vm = this;

        vm.userLogged = null;
        vm.user = null;
        vm.isAdd = false;
        vm.isEdit = false;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;
        vm.addUser = addUser;
        vm.createUser = createUser;
        vm.editUser = editUser;
        vm.updateUser = updateUser;
        vm.cancelAddEdit = cancelAddEdit;

        initController();

        function initController() {
            loadCurrentUser();
            loadAllUsers();
        }

        function loadCurrentUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.userLogged = user;
                });
        }

        function loadAllUsers() {
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                vm.isEdit = false;
                vm.isAdd = false;
                loadAllUsers();
            });
        }

        function addUser() {
            vm.isEdit = false;
            vm.isAdd = true;
            vm.user = {
                role: "Basic"
            };
        }

        function cancelAddEdit() {
            vm.isAdd = false;
            vm.isEdit = false;
        }

        function createUser() {
            vm.dataLoading = true;
            UserService.Create(vm.user)
                .then(function (response) {
                    if (response.success) {
                        loadAllUsers();
                    } else {
                        alert(response.message);
                    }
                    vm.dataLoading = false;
                    vm.isAdd = false;
                });
        }

        function editUser(id) {
            UserService.GetById(id)
                .then(function (user) {
                    vm.user = user;
                    vm.isEdit = true;
                    vm.isAdd = false;
                });
        }

        function updateUser() {
            vm.dataLoading = true;
            UserService.Update(vm.user)
                .then(function () {
                    loadAllUsers();
                    vm.dataLoading = false;
                    vm.isEdit = false;
                });
        }
    }

})();