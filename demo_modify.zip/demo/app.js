﻿(function () {
    'use strict';

    angular
        .module('app', ['ngRoute', 'ngCookies'])
        .config(config)
        .run(run);

    config.$inject = ['$routeProvider', '$locationProvider'];
    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                controller: 'HomeController',
                templateUrl: 'home/home.view.html',
                controllerAs: 'vm'
            })

            .when('/manage', {
                controller: 'ManageController',
                templateUrl: 'manage/user/manage.view.html',
                controllerAs: 'vm'
            })

            .when('/login', {
                controller: 'LoginController',
                templateUrl: 'login/login.view.html',
                controllerAs: 'vm'
            })

            .when('/register', {
                controller: 'RegisterController',
                templateUrl: 'register/register.view.html',
                controllerAs: 'vm'
            })

            .when('/manage-app', {
                controller: 'ManageAppController',
                templateUrl: 'manage/app/manage-app.view.html',
                controllerAs: 'vm'
            })

            .otherwise({ redirectTo: '/login' });
    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http', 'UserService', 'AppService'];
    function run($rootScope, $location, $cookies, $http, UserService, AppService) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookies.getObject('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata;
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in and trying to access a restricted page
            var restrictedPage = $.inArray($location.path(), ['/login', '/register', '/manage']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });

        var user = {
            firstName: 'admin',
            lastName: 'admin',
            role: 'Admin',
            username: 'admin',
            password: 'admin',
        };
        UserService.Create(user);

        var user1 = {
            firstName: 'Thuy',
            lastName: 'Nguyen',
            role: 'Admin',
            username: 'thuynguyen',
            password: 'admin',
        };
        UserService.Create(user1);

        var app = {
            id: "59bb86bc5cf4c8000fdad0bd",
            name: "Fusion",
            sessionExpiration: 20,
            userBase: "Both"
        }

        AppService.Create(app);
    }

})();