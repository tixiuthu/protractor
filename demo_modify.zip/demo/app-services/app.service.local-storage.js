﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('AppService', AppService);

    AppService.$inject = ['$timeout', '$filter', '$q'];
    function AppService($timeout, $filter, $q) {

        var service = {};

        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByName = GetByName;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;

        return service;

        function GetAll() {
            var deferred = $q.defer();
            deferred.resolve(getApps());
            return deferred.promise;
        }

        function GetById(id) {
            var deferred = $q.defer();
            var filtered = $filter('filter')(getApps(), { id: id });
            var app = filtered.length ? filtered[0] : null;
            deferred.resolve(app);
            return deferred.promise;
        }

        function GetByName(name) {
            var deferred = $q.defer();
            var filtered = $filter('filter')(getApps(), { name: name });
            var app = filtered.length ? filtered[0] : null;
            deferred.resolve(app);
            return deferred.promise;
        }

        function Create(app) {
            var deferred = $q.defer();

            // simulate api call with $timeout
            $timeout(function () {
                GetByName(app.name)
                    .then(function (duplicateApp) {
                        if (duplicateApp !== null) {
                            deferred.resolve({ success: false, message: 'App Name "' + app.name + '" is already existed' });
                        } else {
                            var apps = getApps();

                            app.id = generateId();

                            // save to local storage
                            apps.push(app);
                            setApps(apps);

                            deferred.resolve({ success: true });
                        }
                    });
            }, 1000);

            return deferred.promise;
        }

        function generateId() {
            var text = "";
            var possible = "abcdef0123456789";

            for (var i = 0; i < 24; i++)
                text += possible.charAt(Math.floor(Math.random() * possible.length));

            return text;
        }

        function Update(app) {
            var deferred = $q.defer();

            var apps = getApps();
            for (var i = 0; i < apps.length; i++) {
                if (apps[i].id === app.id) {
                    apps[i] = app;
                    break;
                }
            }
            setApps(apps);
            deferred.resolve();

            return deferred.promise;
        }

        function Delete(id) {
            var deferred = $q.defer();

            var apps = getApps();
            for (var i = 0; i < apps.length; i++) {
                var app = apps[i];
                if (app.id === id) {
                    apps.splice(i, 1);
                    break;
                }
            }
            setApps(apps);
            deferred.resolve();

            return deferred.promise;
        }

        // private functions

        function getApps() {
            if(!localStorage.apps){
                localStorage.apps = JSON.stringify([]);
            }

            return JSON.parse(localStorage.apps);
        }

        function setApps(apps) {
            localStorage.apps = JSON.stringify(apps);
        }
    }
})();