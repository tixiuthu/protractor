var jsonReportFile = 'protractor-report/cucumber_report.json';
exports.config = {
    seleniumAddress: 'http://localhost:4444/wd/hub',

    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),

    specs: [
        'demo/features/*.feature'
    ],
    cucumberOpts: {
        require: ['hook.js','demo/steps/*_steps.js'],
        format: 'pretty'
    },
}
