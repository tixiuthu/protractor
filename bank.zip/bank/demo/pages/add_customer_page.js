/**
 * Created by nguyenthihongthuy on 30/08/17.
 */
var expect = require('./../../expect.js');
var AddCustomerPage = function() {

    this.getURL = function(value) {
        browser.get(value);
        browser.sleep(5000);
    };

    this.setFirstName = function(value) {
        element(by.model('fName')).sendKeys(value);
        browser.sleep(1000);
    };

    this.setLastName = function(value) {
        element(by.model('lName')).sendKeys(value);
        browser.sleep(1000);
    };

    this.setPostCode = function(value) {
        element(by.model('postCd')).sendKeys(value);
        browser.sleep(1000);
    };


    this.clickAddCustomer = function() {
        element.all(by.buttonText('Add Customer')).get(1).click();
        browser.sleep(1000);
        browser.switchTo().alert().accept();
    };

    this.verifyAddCustomerExisted = function() {
        expect(element(by.model('fName'))).to.be.present;
        
    };





};

module.exports = AddCustomerPage;
