/**
 * Created by nguyenthihongthuy on 30/08/17.
 */

var AddCustomerSteps = function () {

    var AddCustomerPage = require("../pages/add_customer_page.js");


    this.Before(function (scenario, callback) {
        this.add_custom_page = new AddCustomerPage();
        callback();
    });

    this.Given('I open the website $website', function (website, callback) {
        this.add_custom_page.getURL(website);
        browser.sleep(1000)
        callback();
    });

    this.Then('I verify that add customer screen appears', function (callback) {
        this.add_custom_page.verifyAddCustomerExisted();
        callback();
    });

    this.When('I type first name as $fname , last name as $lname , postcode as $postcode', function (fname, lname, postcode, callback) {
        this.add_custom_page.setFirstName(fname);
        this.add_custom_page.setLastName(lname);
        this.add_custom_page.setPostCode(postcode);
        callback();
    });


    this.When('I click submit button', function (callback) {
        this.add_custom_page.clickAddCustomer();
        callback();
    });
};

module.exports = AddCustomerSteps;