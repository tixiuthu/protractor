/**
 * Created by nguyenthihongthuy on 30/08/17.
 */


var OpenAccountSteps = function () {

    var OpenAccountPage = require("../pages/open_account_page.js");

    this.Before(function (scenario, callback) {
        this.open_account_page = new OpenAccountPage();
        callback();
    });


    this.Then('I check the customer first name as $fname , last name as $lname , postcode as $code has been existed in the customer list', function (fname, lname, code,callback) {
        this.open_account_page.verifyCustomerExisted(fname+' '+lname);
        callback();
    });

    this.Then('I click Open Account button', function (callback) {
        this.open_account_page.clickOpenAccount();
        callback();
    });

    this.Then('I verify that system is navigated to the open account screen', function (callback) {
        this.open_account_page.verifyOpenAccountScreen();
        callback();
    });

    this.Then('I choose customer with name $customer, currency $currency', function (customer,currency,callback) {
        this.open_account_page.setCustomerName(customer);
        this.open_account_page.setCurrency(currency);
        callback();
    });

    this.Then('I click on Process button', function (callback) {
        this.open_account_page.clickProcessBtn();
        callback();
    });




};

module.exports = OpenAccountSteps;